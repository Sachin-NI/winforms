// TSControl.cpp : Implementation of CTSControl
#include "pch.h"
#include "TSControl.h"


// CTSControl

STDMETHODIMP CTSControl::GetTSInfo(BSTR* tsInfo)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	return S_OK;
}
