// dllmain.cpp : Implementation of DllMain.

#include "pch.h"
#include "framework.h"
#include "resource.h"
#include "NIComControl_i.h"
#include "dllmain.h"

CNIComControlModule _AtlModule;

class CNIComControlApp : public CWinApp
{
public:

// Overrides
	virtual BOOL InitInstance();
	virtual int ExitInstance();

	DECLARE_MESSAGE_MAP()
};

BEGIN_MESSAGE_MAP(CNIComControlApp, CWinApp)
END_MESSAGE_MAP()

CNIComControlApp theApp;

BOOL CNIComControlApp::InitInstance()
{
	return CWinApp::InitInstance();
}

int CNIComControlApp::ExitInstance()
{
	return CWinApp::ExitInstance();
}
