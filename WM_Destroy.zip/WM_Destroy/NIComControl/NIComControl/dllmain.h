// dllmain.h : Declaration of module class.

class CNIComControlModule : public ATL::CAtlDllModuleT< CNIComControlModule >
{
public :
	DECLARE_LIBID(LIBID_NIComControlLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_NICOMCONTROL, "{76bceeb4-6932-46fd-98cf-09daae944bb0}")
};

extern class CNIComControlModule _AtlModule;
