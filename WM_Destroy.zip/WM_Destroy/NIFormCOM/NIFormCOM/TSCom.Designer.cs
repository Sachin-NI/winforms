﻿using System.Runtime.InteropServices;
namespace NIFormCOM
{
    partial class TSCom
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);
        private const int WM_DESTROY = 0x0002;
        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            IntPtr hWnd = new IntPtr(axtsControl1.Handle);
            SendMessage(hWnd, WM_DESTROY, IntPtr.Zero, IntPtr.Zero);
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TSCom));
            axtsControl1 = new AxNIComControlLib.AxTSControl();
            ((System.ComponentModel.ISupportInitialize)axtsControl1).BeginInit();
            SuspendLayout();
            // 
            // axtsControl1
            // 
            axtsControl1.Enabled = true;
            axtsControl1.Location = new Point(168, 120);
            axtsControl1.Name = "axtsControl1";
            axtsControl1.OcxState = (AxHost.State)resources.GetObject("axtsControl1.OcxState");
            axtsControl1.Size = new Size(223, 131);
            axtsControl1.TabIndex = 0;
            // 
            // TSCom
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(axtsControl1);
            Name = "TSCom";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)axtsControl1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private AxNIComControlLib.AxTSControl axtsControl1;
    }
}
