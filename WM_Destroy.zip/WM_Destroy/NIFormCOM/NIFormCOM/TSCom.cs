namespace NIFormCOM
{
    public partial class TSCom : Form
    {
        public TSCom()
        {
            InitializeComponent();
        }
    }
}
